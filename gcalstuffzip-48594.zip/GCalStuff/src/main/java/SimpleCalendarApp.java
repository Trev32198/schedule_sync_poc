import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.EventAttendee;
import com.google.api.services.calendar.model.EventReminder;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.Calendar;

import java.util.Scanner; 
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;
import java.text.SimpleDateFormat;

public class SimpleCalendarApp {
    private static final String CAL_APP_NAME = "Simple GCal API For Java";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static final String PATH_TO_TOKENS = "tokens";
	private static final String NEW_EVENT_SUMMARY = "Temporary Test Event";
	private static final String NEW_EVENT_START_TIME = "2020-03-30T09:00:00+05:30";

	// get the scope of the application to obtain the required access permission
	// if this scope is changed at some point, the above tokens folder should be deleted to refresh tokens
    private static final List<String> CAL_APP_SCOPES = Collections.singletonList(CalendarScopes.CALENDAR);
	// the path where generated oauth credentials will be stored
    private static final String PATH_TO_CREDENTIALS = "/credentials.json";
	
	private static Events events;
	private static Calendar calendarService;
	private static boolean eventExists = false;

    /**
     * Creates an authorized Credential object.
     * @param HTTP_TRANSPORT The network HTTP Transport.
     * @return An authorized Credential object.
     * @throws IOException If the credentials.json file cannot be found.
     */
    private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
        // Load client secrets.
        InputStream in = SimpleCalendarApp.class.getResourceAsStream(PATH_TO_CREDENTIALS);
        if (in == null) {
            throw new FileNotFoundException("Credential File '" + PATH_TO_CREDENTIALS + "' was not found");
        }
		
		// load the oauth2 credentials
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, CAL_APP_SCOPES)
				// below code line enables to store the access token locally on the machine
				// to enable user access the resource with just one time permission access
                .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(PATH_TO_TOKENS)))
				// if every time permission should be checked or new login to be done, delete the above line of code
                .setAccessType("offline")
                .setApprovalPrompt("force")
				.build();
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    }

    /**
     * Obtains the upcoming count of events from user's calendar
     * @param countOfEvents, there could be enumerous number of events, so better to give a count.
     * @throws IOException.
     */
	private static void getNextEvents(int countOfEvents) throws IOException {
        DateTime now = new DateTime(System.currentTimeMillis());
		// get the events from the calendar service
        events = calendarService.events().list("primary")
                .setMaxResults(countOfEvents)	// these many only if there are more
                .setTimeMin(now)				// starting now
                .setOrderBy("startTime")		// order by their start time
                .setSingleEvents(true)			// each event individually
                .execute();						// run the query
        List<Event> eventsList = events.getItems();		
	
		// list down all the events found
        if (eventsList.isEmpty()) {
            System.out.println("\n****   No upcoming events found.   ****");
        } else {
            System.out.println("\n****      UPCOMING EVENTS      ****");
            System.out.println("============================================");
			System.out.printf("  Sr.   %-20s   Start Time\n", "Event Name");
            System.out.println("============================================");
			
			int counter = 0;
            for (Event event : eventsList) {
                DateTime start = event.getStart().getDateTime();
                if (start == null) {
                    start = event.getStart().getDate();
                }
				counter++;
                System.out.printf("  %3d   %-20s   %s\n", counter, event.getSummary(), start);
				
				// check if the event we are about to add next, is already existing in the list or not
				if(event.getSummary().equals(NEW_EVENT_SUMMARY) && start.equals(new DateTime(NEW_EVENT_START_TIME))) {
					eventExists = true;
				}
            }
            System.out.println("============================================");
        }
	}
	
    /**
     * Add the new event with already defined static details to the user's calendar
     * @throws IOException.
     */
	private static void createNewEvent() throws IOException {
		// create a new event instance
		Event event = new Event()
			.setSummary(NEW_EVENT_SUMMARY)	// set the title
			.setLocation("Some Dummy Address and Location")	// the location for the event
			.setDescription("Join and learn about the new technical advancements.");	// the description for the event

		DateTime startDateTime = new DateTime(NEW_EVENT_START_TIME);
		EventDateTime start = new EventDateTime()	// instantiate the new eventtime
			.setDateTime(startDateTime);	// set the start time
		event.setStart(start);				// set it rolling

		DateTime endDateTime = new DateTime("2020-03-30T17:00:00+05:30");// the ending time for the event
		EventDateTime end = new EventDateTime()
			.setDateTime(endDateTime);		// set the end time
		event.setEnd(end);					// set to end at this time

		// add attendees for the event.
		EventAttendee[] attendees = new EventAttendee[] {
			new EventAttendee().setEmail("emailone@one.one"),
			new EventAttendee().setEmail("techknow.kg@gmail.com"),
		};
		event.setAttendees(Arrays.asList(attendees));

		// reminder to be given
		EventReminder[] reminderOverrides = new EventReminder[] {
			new EventReminder().setMethod("email").setMinutes(24 * 60),
			new EventReminder().setMethod("popup").setMinutes(10),
		};
		Event.Reminders reminders = new Event.Reminders()
			.setUseDefault(false)
			.setOverrides(Arrays.asList(reminderOverrides));
		event.setReminders(reminders);

		// add the new event to the user's primary calendar
		String calendarId = "primary";
		event = calendarService.events().insert(calendarId, event).setSendNotifications(true).execute();
		System.out.printf("\nEvent created: %s\n", event.getHtmlLink());
	}
	
    public static void main(String... args) throws IOException, GeneralSecurityException {
        // Build a new authorized API client service.
        final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        calendarService = new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                .setApplicationName(CAL_APP_NAME)
                .build();
				
        // List the next 10 events from the primary calendar.
		getNextEvents(10);
		
		System.out.printf("\nNew event '%s' starting '%s' is about to be created\n", NEW_EVENT_SUMMARY, NEW_EVENT_START_TIME);
		if (eventExists) {
			System.out.println("\nThe event already exists...Not Required to add again.");
			return;
		}
		
		// Event does not exist, create the new event
		createNewEvent();
    }
}